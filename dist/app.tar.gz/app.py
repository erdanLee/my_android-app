import flet as ft

def main(page: ft.Page):
    page.title = "My Tasks - Public"
    page.theme_mode = "light"
    page.padding = 20

    tasks = ft.Column()

    def add_task(e):
        if new_task.value:
            tasks.controls.append(
                ft.Row([
                    ft.Checkbox(),
                    ft.Text(new_task.value, size=18),
                    ft.IconButton(
                        icon="delete_outline",
                        icon_color="red",
                        on_click=lambda _: tasks.controls.remove(_.control.parent)
                    )
                ])
            )
            new_task.value = ""
            page.update()

    new_task = ft.TextField(hint_text="New task...", expand=True)
    page.add(
        ft.Text("📝 My Public Tasks", size=24),
        ft.Row([new_task, ft.IconButton(icon="add", on_click=add_task)]),
        tasks
    )